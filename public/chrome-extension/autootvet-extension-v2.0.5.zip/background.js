console.log('Автоответ background started');

// ====== КОНСТАНТЫ ======

const OZON_REVIEWS_URL = "https://seller.ozon.ru/app/postings/reviews";

const BACKEND_URL = 'https://nxymhkyvhcfcwjcfcbfy.supabase.co/functions/v1';

// Состояние по умолчанию — то, что мы храним в chrome.storage.local
const defaultState = {
  autoScan: false,           // автоскан включён?
  scanIntervalMin: 10,       // каждые X минут
  verifiedEmail: "",         // сервисная почта из Озона
  sellerId: "",              // sellerId из Озона
  marketplaceId: null,       // ID магазина в нашей БД Supabase (UUID из marketplaces)
  lastScanAt: null,          // когда последний раз сканировали
  lastScanCount: 0,          // сколько нашли в последний раз
  lastError: "",             // последний текст ошибки
  sessionStatus: "inactive", // inactive | active | paused | error
  failCount: 0,              // сколько подряд ошибок критических
};

// ====== УТИЛИТЫ ХРАНЕНИЯ СОСТОЯНИЯ ======

async function getState() {
  const st = await chrome.storage.local.get(Object.keys(defaultState));
  return { ...defaultState, ...st };
}

async function setState(patch) {
  await chrome.storage.local.set(patch);
  // уведомляем popup чтобы он обновился
  chrome.runtime.sendMessage({ type: "STATE_UPDATED" }).catch(() => {});
}

// ====== INIT ПРИ УСТАНОВКЕ / ОБНОВЛЕНИИ РАСШИРЕНИЯ ======

chrome.runtime.onInstalled.addListener(async () => {
  console.log('Автоответ installed/updated');
  await setState(defaultState);
  schedulePublishAlarm();
});

// ====== ФУНКЦИИ ПРО РАБОТУ С ВКЛАДКОЙ OZON ======

async function ensureTab() {
  // пытаемся найти уже открытую вкладку с Ozon Seller
  let tabs = await chrome.tabs.query({ url: "https://seller.ozon.ru/*" });
  let tab = tabs[0];

  if (!tab) {
    console.log('Открываем вкладку Ozon');
    tab = await chrome.tabs.create({
      url: OZON_REVIEWS_URL,
      active: false,
    });
    // ждём чуть-чуть, чтобы страница успела подгрузиться
    await new Promise(r => setTimeout(r, 3000));
  }

  // просим Chrome не выгружать вкладку из памяти
  try {
    await chrome.tabs.update(tab.id, { autoDiscardable: false });
  } catch (e) {
    console.warn('autoDiscardable error:', e);
  }

  return tab.id;
}

// ====== ЗАПУСК СКАНИРОВАНИЯ (внедрение контент-скрипта) ======

async function runScan() {
  console.log('Запуск сканирования...');
  const state = await getState();

  // Проверяем, можем ли вообще сканировать
  if (
    !state.verifiedEmail ||
    !state.sellerId ||
    !state.marketplaceId ||
    state.sessionStatus !== 'active'
  ) {
    console.error('Условия для автосканирования не выполнены');
    await setState({
      sessionStatus: "error",
      lastError: "NOT_CONNECTED",
    });

    if (!state.marketplaceId) {
      notify(
        'Автоответ',
        'Укажите ID магазина из Автоответ в настройках расширения'
      );
    } else {
      notify('Автоответ', 'Сначала подключите магазин в расширении');
    }
    return;
  }

  try {
    const tabId = await ensureTab();

    // запускаем content.js в этой вкладке
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ['content.js'],
    });

    console.log('content.js внедрён');
  } catch (error) {
    console.error('Ошибка запуска контент-скрипта:', error);
    await setState({
      lastError: "EXEC_SCRIPT_FAIL",
      sessionStatus: "error",
    });
    notify(
      'Автоответ',
      'Не удалось запустить скан. Проверьте вход в Ozon.'
    );
  }
}

// ====== НАСТРОЙКА ТАЙМЕРОВ (ALARMS) ======

function scheduleAlarm(periodMin) {
  chrome.alarms.clear("scan");
  const period = Math.max(5, Number(periodMin) || 10);
  chrome.alarms.create("scan", { periodInMinutes: period });
  console.log(Аларм сканирования каждые ${period} мин);
}

function schedulePublishAlarm() {
  chrome.alarms.create("publish", { periodInMinutes: 1 });
  console.log('Аларм публикации ответов включён');
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === "scan") {
    const state = await getState();
    if (!state.autoScan) return;
    await runScan();
    return;
  }

  if (alarm.name === "publish") {
    await checkPendingReplies(); // будет без запроса к backend (временно)
    return;
  }
});

// ====== ПУБЛИКАЦИЯ ОТВЕТОВ (ОЧЕРЕДЬ ОТВЕТОВ) ======
//
// ВНИМАНИЕ:
// Сейчас backend-метод get_pending_replies ещё не готов,
// поэтому мы убираем сетевой запрос, чтобы не было ошибки 500.
// Логика отправки ответов в Озон останется на месте,
// просто не будет попытки получить очередь из сервера.

async function checkPendingReplies() {
  const state = await getState();

  if (!state.marketplaceId || state.sessionStatus !== 'active') {
    return;
  }

  try {
    // ВРЕМЕННО:
    // раньше тут был fetch(BACKEND_URL, { action: 'get_pending_replies', ... })
    // который падал на 500.
    console.log(
      '[Автоответ BG] checkPendingReplies: публикация автоответов пока выключена'
    );

    // когда будет готов backend, сюда вернём:
    //
    // const resp = await fetch(BACKEND_URL + '/get-pending-replies', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify({
    //     marketplace_id: state.marketplaceId,
    //   }),
    // });
    //
    // if (!resp.ok) return;
    // const { replies } = await resp.json();
    // if (replies && replies.length > 0) {
    //   console.log(Есть ${replies.length} ответ(ов) для публикации);
    //   for (const r of replies) {
    //     await publishReply(r);
    //   }
    // }

  } catch (err) {
    console.error(
      '[Автоответ BG] Ошибка получения очереди ответов:',
      err
    );
  }
}

// Фактическая отправка ответа назад в content.js,
// чтобы он попытался опубликовать текст в интерфейсе Озона.
async function publishReply(reply) {
  try {
    const tabId = await ensureTab();
    const response = await chrome.tabs.sendMessage(tabId, {
      type: 'PUBLISH_REPLY',
      payload: reply,
    });

    if (response && response.success) {
      await setState({ failCount: 0 });
    }
  } catch (error) {
    console.error('[Автоответ BG] Ошибка публикации ответа:', error);
    await handlePublishFailure(error, reply);
  }
}

// ====== ПРИЁМ СООБЩЕНИЙ ИЗ content.js / popup.js ======

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  console.log('BG получил сообщение:', msg.type);

  if (msg.type === "SCAN_RESULT") {
    handleScanResult(msg.payload).then(() => sendResponse({ ok: true }));
    return true; // async
  }

  if (msg.type === "PUBLISH_RESULT") {
    handlePublishResult(msg.payload).then(() => sendResponse({ ok: true }));
    return true; // async
  }

  if (msg.type === "RESCHEDULE_ALARM") {
    getState().then(state => {
      scheduleAlarm(state.scanIntervalMin);
      schedulePublishAlarm();
      sendResponse({ ok: true });
    });
    return true;
  }

  if (msg.type === "SCAN_NOW") {
    runScan().then(() => sendResponse({ ok: true }));
    return true;
  }

  return false;
});

// ====== ОБРАБОТКА РЕЗУЛЬТАТОВ СКАНА ОТ CONTENT.JS ======

async function handleScanResult(payload) {
  console.log('[Автоответ BG] handleScanResult payload:', payload);

  const criticalErrors = [
    'AUTH_REQUIRED',
    'CAPTCHA_DETECTED',
    'DOM_NOT_FOUND'
  ];

  // если контент-скрипт сообщил критическую ошибку (типа "нет DOM" и т.д.)
  if (payload?.error && criticalErrors.includes(payload.error)) {
    const state = await getState();
    const newFailCount = (state.failCount || 0) + 1;

    await setState({
      failCount: newFailCount,
      lastError: payload.error,
    });

    // если таких ошибок подряд стало много — стопаем автоматизацию
    if (newFailCount >= 3) {
      await triggerKillSwitch();
      return;
    }
  }

  const state = await getState();

  // массивы отзывов/вопросов, даже если их нет
  const reviews = Array.isArray(payload.reviews) ? payload.reviews : [];
  const questions = Array.isArray(payload.questions) ? payload.questions : [];
  const totalFound = reviews.length + questions.length;

  // сохраняем инфу о последнем скане
  await setState({
    lastScanAt: new Date().toISOString(),
    lastScanCount: totalFound,
    lastError: "",
    failCount: 0,
  });

  // отправляем всё это на backend (sync_reviews) даже если totalFound === 0
  try {
    const resp = await fetch(BACKEND_URL + '/sync-reviews', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'sync_reviews',
        marketplace_id: state.marketplaceId,
        reviews,
        questions,
        extension_version: '2.0.0',
      }),
    });

    if (!resp.ok) {
      throw new Error(Backend error: ${resp.status});
    }

    const result = await resp.json();
    console.log('[Автоответ BG] backend sync -> готовим данные:', {
      marketplace_id: state.marketplaceId,
      questionsCount: questions.length,
      reviewsCount: reviews.length,
    });
    console.log('[Автоответ BG] backend ответил:', result);

    if (totalFound === 0) {
      notify('Автоответ', 'Новых отзывов не найдено');
    } else {
      notify('Автоответ', `Получено ${totalFound} элементов`);
    }
  } catch (err) {
    console.error('[Автоответ BG] Ошибка отправки на backend:', err);

    await setState({
      lastError: "INGEST_FAIL",
    });

    notify(
      'Автоответ',
      'Не удалось отправить данные на сервер'
    );
  }
}

// ====== ОБРАБОТКА РЕЗУЛЬТАТА ПУБЛИКАЦИИ ОТВЕТА ======

async function handlePublishResult(payload) {
  console.log('[Автоответ BG] handlePublishResult:', payload);

  const state = await getState();

  try {
    // говорим бэкенду, что ответ опубликован / не опубликован
    await fetch(BACKEND_URL + '/mark-reply-published', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        reply_id: payload.reply_id,
        success: payload.success,
        error_message: payload.error,
      }),
    });

    if (payload.success) {
      // успех — сбрасываем счётчик неудач
      await setState({ failCount: 0 });
    } else {
      // неуспех — возможна капча или не авторизованы
      if (
        payload.error === 'CAPTCHA_DETECTED' ||
        payload.error === 'AUTH_REQUIRED'
      ) {
        const newFailCount = (state.failCount || 0) + 1;
        await setState({ failCount: newFailCount });

        if (newFailCount >= 3) {
          await triggerKillSwitch();
        }
      }
    }
  } catch (err) {
    console.error('[Автоответ BG] Ошибка mark_reply_published:', err);
  }
}

// ====== ОБРАБОТКА НЕУДАЧИ ПУБЛИКАЦИИ ======

async function handlePublishFailure(error, reply) {
  const state = await getState();
  const newFailCount = (state.failCount || 0) + 1;
  await setState({ failCount: newFailCount });

  if (newFailCount >= 3) {
    await triggerKillSwitch();
  }
}

// ====== АВАРИЙНАЯ ОСТАНОВКА (kill-switch) ======

async function triggerKillSwitch() {
  const state = await getState();

  console.warn('[Автоответ BG] АКТИВИРУЕМ KILL-SWITCH');

  // локально выключаем автоскан
  await setState({
    autoScan: false,
    sessionStatus: 'paused',
    lastError: 'KILL_SWITCH_ACTIVATED',
  });

  // сообщаем серверу, что нас надо приостановить
  try {
    await fetch(BACKEND_URL + '/fallback-webhook', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action_type: 'kill_switch_triggered',
        marketplace_id: state.marketplaceId,
      }),
    });
  } catch (err) {
    console.error(
      '[Автоответ BG] Ошибка kill-switch в backend:',
      err
    );
  }

  notify(
    '⛔ Автоответ',
    'Автоматизация остановлена. Войдите в Ozon заново и включите снова.'
  );
}

// ====== УВЕДОМЛЕНИЯ Chrome ======

function notify(title, message) {
  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'icon128.png',
    title,
    message,
  });
}

console.log('Автоответ background initialized');
 
   

