console.log('[Автоответ] Контент-скрипт запущен на:', window.location.href);

(async () => {
  try {
    // Read last sync dates from storage
    const storage = await chrome.storage.local.get(['lastReviewDate', 'lastQuestionDate']);
    const lastReviewDate = storage.lastReviewDate ? new Date(storage.lastReviewDate) : null;
    const lastQuestionDate = storage.lastQuestionDate ? new Date(storage.lastQuestionDate) : null;
    
    console.log('[Автоответ] Последние даты синхронизации:', {
      lastReviewDate: lastReviewDate?.toISOString(),
      lastQuestionDate: lastQuestionDate?.toISOString()
    });

    async function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

    async function waitFor(selector, timeout = 5000) {
      const start = Date.now();
      while (Date.now() - start < timeout) {
        const el = document.querySelector(selector);
        if (el) return el;
        await sleep(100);
      }
      return null;
    }

    async function scrollAndCollectRows(maxScrolls = 30) {
      let prevCount = 0;
      let attempts = 0;
      while (attempts < maxScrolls) {
        const currentRows = document.querySelectorAll('table tbody tr');
        if (currentRows.length === prevCount) {
          const moreBtn = Array.from(document.querySelectorAll('button, a'))
            .find(b => /ещ[её]/i.test(b.innerText || ''));
          if (moreBtn) {
            moreBtn.click();
            await sleep(1000);
          } else {
            break;
          }
        } else {
          prevCount = currentRows.length;
        }

        document.documentElement.scrollTop = document.documentElement.scrollHeight;
        await sleep(600);
        attempts++;
      }

      return Array.from(document.querySelectorAll('table tbody tr'));
    }

    function extractProductExternalId(row) {
      const productLink = row.querySelector('a[href*="/product/"], a[href*="/sku/"]');
      if (productLink && productLink.href) {
        const m = productLink.href.match(/product\/(\d+)|sku\/([A-Za-z0-9-]+)/);
        if (m) return m[1] || m[2];
      }
      const txt = row.innerText || '';
      const skuMatch = txt.match(/SKU[:\s]+([A-Z0-9-]+)/i);
      if (skuMatch) return skuMatch[1];
      return null;
    }

    async function maybeOpenDetails(row) {
      const data = { advantages: '', disadvantages: '', photos: [] };
      try {
        const moreBtn = Array
          .from(row.querySelectorAll('button, [role="button"], a'))
          .find(el => /подробнее|детал/i.test(el.innerText || ''));
        if (!moreBtn) return data;

        moreBtn.click();
        await sleep(400);

        const modal = document.querySelector('[class*="modal"], [role="dialog"], [class*="popup"]');
        if (modal) {
          const advNode = Array.from(modal.querySelectorAll('*'))
            .find(n => /достоинств/i.test(n.innerText || ''));
          if (advNode) {
            data.advantages = advNode.innerText
              .replace(/достоинств[аы]?:?/i, '')
              .trim();
          }

          const disNode = Array.from(modal.querySelectorAll('*'))
            .find(n => /недостатк|минус/i.test(n.innerText || ''));
          if (disNode) {
            data.disadvantages = disNode.innerText
              .replace(/недостатк[и]?|минус[ы]?:?/i, '')
              .trim();
          }

          const imgs = modal.querySelectorAll('img');
          data.photos = Array
            .from(imgs)
            .map(img => img.src)
            .filter(src => src && !src.includes('placeholder'));

          const closeBtn = modal.querySelector('[class*="close"], [aria-label*="Close"], [aria-label*="Закрыть"], button[class*="close"]');
          if (closeBtn) {
            closeBtn.click();
            await sleep(200);
          }
        }
      } catch (e) {
        console.warn('[Автоответ] modal parse err:', e);
      }
      return data;
    }

    function parseDate(dateStr) {
      if (!dateStr) return null;
      try {
        return new Date(dateStr);
      } catch (e) {
        return null;
      }
    }

    function isNewItem(createdAt, lastDate) {
      if (!createdAt) return false;
      const itemDate = parseDate(createdAt);
      if (!itemDate || isNaN(itemDate.getTime())) return false;
      if (!lastDate) return true; // First sync - include all
      return itemDate > lastDate;
    }

    function checkIsNewStatus(row) {
      // Check if row has "Новый" or "Непросмотренный" status
      const statusCell = row.querySelector('[class*="status"], [class*="badge"], td:nth-child(7), td:nth-child(8)');
      if (statusCell) {
        const statusText = statusCell.innerText.trim().toLowerCase();
        return /новый|непросмотренн|new|unread/i.test(statusText);
      }
      return false;
    }

    async function collectReviewsAndQuestions() {
      await waitFor('table tbody tr', 3000);
      const rows = await scrollAndCollectRows(30);

      const reviews = [];
      const questions = [];
      const MAX_ITEMS_PER_TYPE = 50;

      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];

        const productCell = row.querySelector('td:nth-child(1)');
        const productName = productCell ? productCell.innerText.trim() : '';

        const textCell = row.querySelector('td:nth-child(3), td:nth-child(4)');
        const mainText = textCell ? textCell.innerText.trim() : '';

        const dateCell =
          row.querySelector('time, [class*="date"], td:nth-child(2), td:nth-child(5), td:nth-child(6)');
        const createdAt = dateCell
          ? (dateCell.getAttribute('datetime') || dateCell.innerText.trim())
          : '';

        let authorName = '';
        const authorNode = row.querySelector('[class*="author"], [class*="buyer"], [class*="user"]');
        if (authorNode) {
          authorName = authorNode.innerText.trim();
        }

        const prodExternal = extractProductExternalId(row);

        const ratingCell = row.querySelector('[class*="rating"], [class*="star"]');
        let rating = 0;
        if (ratingCell) {
          const raw = ratingCell.innerText || '';
          rating = parseInt(raw.replace(/[^\d]/g, ''), 10) || 0;
        }

        const externalId =
          row.getAttribute('data-id') ||
          row.getAttribute('data-review-id') ||
          row.getAttribute('data-question-id') ||
          `${prodExternal || productName}-${createdAt}-${mainText.slice(0,50)}`;

        if (!mainText && !productName) continue;

        // Check if item is new (by status or date)
        const hasNewStatus = checkIsNewStatus(row);
        const isNewByDate = rating > 0 
          ? isNewItem(createdAt, lastReviewDate)
          : isNewItem(createdAt, lastQuestionDate);

        // Skip if not new and we're not on first sync
        if (!hasNewStatus && !isNewByDate && (lastReviewDate || lastQuestionDate)) {
          continue;
        }

        if (rating > 0) {
          // This is a review
          if (reviews.length >= MAX_ITEMS_PER_TYPE) continue;

          const extra = await maybeOpenDetails(row);

          reviews.push({
            external_id: externalId,
            product_external_id: prodExternal || productName,
            product_name: productName,
            author_name: authorName,
            text: mainText,
            advantages: extra.advantages || '',
            disadvantages: extra.disadvantages || '',
            rating: rating,
            created_at: createdAt,
            photos: extra.photos || [],
          });
        } else {
          // This is a question
          if (questions.length >= MAX_ITEMS_PER_TYPE) continue;

          questions.push({
            external_id: externalId,
            product_external_id: prodExternal || productName,
            product_name: productName,
            author_name: authorName,
            text: mainText,
            created_at: createdAt,
          });
        }

        if (i % 5 === 0) {
          await sleep(200);
        }
      }

      return { reviews, questions };
    }

    const { reviews, questions } = await collectReviewsAndQuestions();

    // Calculate and save newest dates
    if (reviews.length > 0) {
      const newestReviewDate = reviews.reduce((latest, review) => {
        const reviewDate = parseDate(review.created_at);
        if (!reviewDate || isNaN(reviewDate.getTime())) return latest;
        return !latest || reviewDate > latest ? reviewDate : latest;
      }, null);
      
      if (newestReviewDate) {
        await chrome.storage.local.set({ 
          lastReviewDate: newestReviewDate.toISOString() 
        });
        console.log('[Автоответ] Сохранена новая дата последнего отзыва:', newestReviewDate.toISOString());
      }
    }

    if (questions.length > 0) {
      const newestQuestionDate = questions.reduce((latest, question) => {
        const questionDate = parseDate(question.created_at);
        if (!questionDate || isNaN(questionDate.getTime())) return latest;
        return !latest || questionDate > latest ? questionDate : latest;
      }, null);
      
      if (newestQuestionDate) {
        await chrome.storage.local.set({ 
          lastQuestionDate: newestQuestionDate.toISOString() 
        });
        console.log('[Автоответ] Сохранена новая дата последнего вопроса:', newestQuestionDate.toISOString());
      }
    }

    console.log('[Автоответ] Найдено новых элементов:', {
      reviews: reviews.length,
      questions: questions.length
    });

    chrome.runtime.sendMessage({
      type: "SCAN_RESULT",
      payload: {
        reviews,
        questions,
        error: (!reviews.length && !questions.length) ? 'DOM_NOT_FOUND' : undefined,
      },
    });

  } catch (err) {
    console.error('[Автоответ] Ошибка контент-скрипта:', err);
    chrome.runtime.sendMessage({
      type: "SCAN_RESULT",
      payload: {
        reviews: [],
        questions: [],
        error: "CONTENT_JS_ERROR",
        detail: String(err),
      },
    });
  }
})();
